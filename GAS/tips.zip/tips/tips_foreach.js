function GAS_(){
  let lists = [1,2,3,4,5,6];
  lists.forEach(function(key){
    Logger.log(key);
  });

  
}
