function GAS_(){
  let url = "https://stocks.finance.yahoo.co.jp/us/detail/TSLA";
  let html = UrlFetchApp.fetch(url).getContentText("UTF-8");
  
}
